package com.seiren.pocketcodestudio;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.webkit.ValueCallback;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 71;
    private static final int SAVE_FILE = 72;
    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private byte[] pendingSave;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,19,30));
        getWindow().setNavigationBarColor(Color.rgb(16,19,30));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16,19,30));
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new AndroidExports(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("https".equals(url.getScheme()) && LOCAL_HOST.equals(url.getHost())) {
                    String path = url.getPath();
                    if ("/".equals(path) || "/index.html".equals(path)) {
                        try {
                            InputStream stream = getAssets().open("index.html");
                            return new WebResourceResponse("text/html", "UTF-8", stream);
                        } catch (IOException ignored) { }
                    }
                    return blocked();
                }
                return blocked(); // Offline only: no remote web requests.
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return request.isForMainFrame() && !LOCAL_HOST.equals(request.getUrl().getHost());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView web, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(intent, PICK_FILE);
                    return true;
                } catch (ActivityNotFoundException ex) {
                    uploadCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No file picker available", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.loadUrl("https://" + LOCAL_HOST + "/index.html");
    }

    private WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", Collections.emptyMap(),
            new ByteArrayInputStream("Offline mode".getBytes(StandardCharsets.UTF_8)));
    }

    private class AndroidExports {
        @JavascriptInterface public void saveBase64(String suggestedName, String encoded) {
            // Only writes user-approved files via the Android system file picker.
            if (encoded == null || encoded.length() > 40_000_000) return;
            byte[] bytes;
            try { bytes = Base64.decode(encoded, Base64.DEFAULT); }
            catch (IllegalArgumentException e) { return; }
            String filename = suggestedName == null ? "project.zip" : suggestedName.replace('/', '_').replace('\\', '_');
            runOnUiThread(() -> {
                pendingSave = bytes;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/octet-stream");
                intent.putExtra(Intent.EXTRA_TITLE, filename);
                try { startActivityForResult(intent, SAVE_FILE); }
                catch (ActivityNotFoundException ex) {
                    pendingSave = null;
                    Toast.makeText(MainActivity.this, "No file saving app found", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE) {
            if (uploadCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    result = new Uri[count];
                    for (int i = 0; i < count; i++) result[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) result = new Uri[]{ data.getData() };
            }
            uploadCallback.onReceiveValue(result);
            uploadCallback = null;
        } else if (requestCode == SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSave != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingSave);
                        Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException ex) {
                    Toast.makeText(this, "Save failed: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingSave = null;
        }
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("(function(){let p=document.getElementById('preview-back');if(p&&p.classList.contains('visible')){document.getElementById('preview-close').click();return true}let m=document.getElementById('modal-back');if(m&&m.classList.contains('visible')){document.getElementById('modal-close').click();return true}return false})()", value -> {
            if (!"true".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
